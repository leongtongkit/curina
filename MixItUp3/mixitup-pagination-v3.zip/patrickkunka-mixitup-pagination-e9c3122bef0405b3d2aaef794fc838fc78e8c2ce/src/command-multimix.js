/* globals mixitup */

mixitup.CommandMultimix.registerAction('afterConstruct', 'pagination', function() {
    this.paginate = null;
});